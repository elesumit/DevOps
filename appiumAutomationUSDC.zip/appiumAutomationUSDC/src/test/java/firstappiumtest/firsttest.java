package firstappiumtest;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class firsttest {

	public static void main(String[] args) throws MalformedURLException {

        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability(MobileCapabilityType.PLATFORM_NAME, "ANDROID");
        cap.setCapability(MobileCapabilityType.VERSION, "10.0");
        cap.setCapability(MobileCapabilityType.DEVICE_NAME, "emulator-5554");
     //cap.setCapability(MobileCapabilityType.APP,System.getProperty("user.dir") + "/src/test/resources/selendroid-test-app-0.17.0.apk");
        cap.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");

        AndroidDriver<MobileElement> driver = new AndroidDriver<>(new URL("http://127.0.0.1:4723/wd/hub"),cap);

	
		
		
		
	}
	
	
}
