
package com.deloitte.mobileapplication.webdriverinteraction;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.deloitte.mobileapplication.appconstants.AppConstants;
import com.deloitte.mobileapplication.fileOperations.FileOperations;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class AppFactory {

	public static AppiumDriver<WebElement> appDriver;
	/**
	 * This method will open browser according to user argument passed
	 * 
	 * @param browser
	 * @return it will return the driver
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	public static AppiumDriver<WebElement> getApp() throws IOException {
		String browser = FileOperations.DerivergetProperty(AppConstants.BROWSER);
		switch (browser.toUpperCase()) {
		
		case "ANDRIOD":
			appDriver = (AppiumDriver<WebElement>) andriod();
			break;
		case "IOS":
			appDriver = (AppiumDriver<WebElement>) ios();
			break;
	
	

		}
		return appDriver;

	}


	public static AppiumDriver andriod() throws IOException {
	     DesiredCapabilities capabilities = DesiredCapabilities.android();
	     capabilities.setCapability("deviceName", "emulator-5554");
	     capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
         capabilities.setCapability("platformName", "Android");         
        //capabilities.setCapability("platformVersion","11");      
         capabilities.setCapability("appPackage", "com.android.contacts");
         capabilities.setCapability("appActivity", "com.android.contacts.activities.PeopleActivity");           
         appDriver = new AndroidDriver<WebElement> (new URL("http://127.0.0.1:4723/wd/hub"),capabilities);      
               
        return  appDriver;
	}
	
	public static AppiumDriver ios() throws IOException {
	     DesiredCapabilities capabilities = DesiredCapabilities.android();
	     capabilities.setCapability("deviceName", "emulator-5554");
	     capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
       capabilities.setCapability("platformName", "Android");         
       //capabilities.setCapability("platformVersion","11");      
       capabilities.setCapability("appPackage", "com.android.contacts");
       capabilities.setCapability("appActivity", "com.android.contacts.activities.PeopleActivity");           
       appDriver = new AndroidDriver<WebElement> (new URL("http://127.0.0.1:4723/wd/hub"),capabilities);      
              
       return  appDriver;
	}

		


// end of class
}