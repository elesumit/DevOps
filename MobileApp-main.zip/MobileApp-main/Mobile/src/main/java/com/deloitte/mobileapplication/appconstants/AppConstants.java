


package com.deloitte.mobileapplication.appconstants;


public class AppConstants {
	public static String BROWSER="Browser";
	public static String URL="URL";
	public static String APPIUMSERVERPATH="appiumserverpath";
	public static String USERNAME="USERNAME";
	public static String PASSWORD="PASSWORD";
	public static String APP_PACKAGE="Apppackage";
	public static String APP_ACTIVITY="Apppactivity";
	public static String HUBADDRESS="HubAddress";
	public static String DEVICETOEXECUTE="DeviceTOExecute";
	public static String APKFILENAME="ApkFileName";
	public static String MODLA1="MODLA1";
	
	
	//end of class
}
