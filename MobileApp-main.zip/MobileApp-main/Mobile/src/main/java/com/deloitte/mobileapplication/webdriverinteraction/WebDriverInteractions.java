/**
 * @Project:ELITA
 * @Framework Developed by : Sunil Bhajantri
 * @Company:NIIT Technologies
 */
package com.deloitte.mobileapplication.webdriverinteraction;


import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.security.Credentials;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.deloitte.mobileapplication.fileOperations.ByOperations;
import com.deloitte.mobileapplication.fileOperations.FileOperations;
import com.google.common.base.Function;

public class WebDriverInteractions {
	private HashMap<String, WebDriver> driverList = new HashMap<String, WebDriver>();
	private HashMap<String, ArrayList<String>> windowHandlesList = new HashMap<String, ArrayList<String>>();

	public WebDriverInteractions() {
	
	}
	public boolean isCurrentDriverNull() {
		if (driverList.get(Thread.currentThread().getName()) == null) {
			return true;
		} else {
			return false;
		}
	}

	private String getCurrentThreadName() {
		try {
			return Thread.currentThread().getName().isEmpty() ? "default" : Thread.currentThread().getName();
		} catch (Exception e) {
			return "default";
		}
	}

	public synchronized WebDriver getCurrentDriver() throws IOException {

		if (driverList.get(getCurrentThreadName()) == null) {
			windowHandlesList.put(getCurrentThreadName(), new ArrayList<String>());
			windowHandlesList.get(getCurrentThreadName()).clear();
			try {
				driverList.put(getCurrentThreadName(), BrowserFactory.getBrowser());
			} catch (UnreachableBrowserException e) {
				driverList.put(getCurrentThreadName(), BrowserFactory.getBrowser());
			} catch (WebDriverException e) {
				driverList.put(getCurrentThreadName(), BrowserFactory.getBrowser());
			}
			addWindowHandleToArrayList();
		}
		return driverList.get(getCurrentThreadName());
	}

	public void switchtoframe(int num) throws IOException {
		waitForPageLoad();
		getCurrentDriver().switchTo().defaultContent();
		getCurrentDriver().switchTo().frame(num);
	}

	public void switchtoframe(String framename) throws IOException {
		waitForPageLoad();
		try {
			getCurrentDriver().switchTo().frame(getCurrentDriver().findElement(By.className(framename)));
		} catch (NoSuchFrameException | NoSuchElementException e) {
			getCurrentDriver().switchTo().frame(getCurrentDriver().findElement(By.id(framename)));

		}
	}

	public Actions getActionsInstance() throws IOException {
		Actions seriesofAction = new Actions(getCurrentDriver());
		return seriesofAction;

	}

	public void quitAllBrowsers() throws UnreachableBrowserException {
		try {
			if (driverList.get(getCurrentThreadName()) != null) {
				getCurrentDriver().quit();
				driverList.remove(getCurrentThreadName());
				windowHandlesList.remove(getCurrentThreadName());
			}
		} catch (Exception e) {
		}
	}

	public String captureText(String propName) throws IOException {
		String elementValue = "";
		elementValue = findElement(ByOperations.getByargument(propName)).getText();
		return elementValue;
	}

	public FluentWait<WebDriver> getFluentWait() {
		List<Class<? extends Throwable>> ignoreExceptionClasses = new ArrayList<Class<? extends Throwable>>();
		ignoreExceptionClasses.add(NoSuchElementException.class);
		ignoreExceptionClasses.add(ElementNotVisibleException.class);
		ignoreExceptionClasses.add(InvalidElementStateException.class);
		ignoreExceptionClasses.add(StaleElementReferenceException.class);
		try {
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(getCurrentDriver()).withTimeout(60, TimeUnit.SECONDS)
					.pollingEvery(1, TimeUnit.SECONDS).ignoreAll(ignoreExceptionClasses);
			return wait;
		} catch (Exception e) {
		}
		return null;

	}

	public void uploadFile(String propName, String filePath) throws IOException {
		WebElement fileUploadWebElement = findElement(propName);
		fileUploadWebElement.sendKeys(filePath);
	}

	public void type(String propName, String strValue) throws IOException {
		WebElement webElement = findElement(propName);
		webElement.clear();
		((JavascriptExecutor) getCurrentDriver()).executeScript("arguments[0].value = arguments[1];", webElement,
				strValue);
	}

	public void sendKeys(String propName, String strValue) throws IOException {
		WebElement webElement = findElement(propName);
		webElement.clear();
		webElement.sendKeys(strValue);
	}

	public List<WebElement> findElements(String propName) throws IOException {
		return findElements(propName, false);
	}

	public List<WebElement> findElements(final By locator) {
		return findElements(locator, false);
	}

	public List<WebElement> findElements(String propName, boolean waitForElementsVisibility) throws IOException {
		final By by = ByOperations.getByargument(propName);
		return findElements(by, waitForElementsVisibility);
	}

	public String getEditboxDefaultValue(String propName) throws IOException {
		return findElement(propName).getAttribute("value");
	}

	public List<WebElement> findElements(final By locator, boolean waitForElementsVisibility) {
		FluentWait<WebDriver> wait = getFluentWait();
		if (waitForElementsVisibility) {
			return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
		} else {
			return wait.until(new Function<WebDriver, List<WebElement>>() {
				public List<WebElement> apply(WebDriver webDriver) {
					return webDriver.findElements(locator);
				}
			});
		}
	}

	public WebElement getParent(final By locator) {
		return findElement(locator).findElement(By.xpath(".."));
	}

	public WebElement getParent(String propName) throws IOException {
		return findElement(propName).findElement(By.xpath(".."));
	}

	public WebElement findElement(final By locator) {
		FluentWait<WebDriver> wait = getFluentWait();
		return wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver webDriver) {
				return webDriver.findElement(locator);
			}
		});
	}

	public WebElement findElement(String propName) throws IOException {
		final By by = ByOperations.getByargument(propName);
		return findElement(by);
	}

	public void select(String propName, String strValue) throws IOException {
		Select select = new Select(findElement(propName));
		select.selectByVisibleText(strValue);
	}

	public void selectByValue(String propName, String strValue) throws IOException {
		Select select = new Select(findElement(propName));
		select.selectByValue(strValue);
	}


	
	public void selectByIndex(String propName, String strValue) throws IOException {
		int index = Integer.parseInt(strValue);
		Select select = new Select(findElement(propName));
		select.selectByIndex(index);

	}

	public String getSelectedItemInList(String propName) throws IOException {
		Select select = new Select(findElement(propName));
		return select.getFirstSelectedOption().getText();

	}

	public void click(String propName) throws IOException {
		By by = ByOperations.getByargument(propName);
		click(by);
	}

	public void waitForPageLoad() {
		FluentWait<WebDriver> wait = getFluentWait();
		try {
			Thread.sleep(1000);
			wait.until(new Function<WebDriver, Boolean>() {

				public Boolean apply(WebDriver webDriver) {
					return String.valueOf(((JavascriptExecutor) webDriver).executeScript("return document.readyState"))
							.equals("complete");
				}
			});
		} catch (Exception e) {
		}
	}

	public void waitforAjaxload() {
		try {
			Thread.sleep(1000);
			for (int i = 0; i <= 30; i++) {
				if (getCurrentDriver().findElement(By.cssSelector(".processing-modal-content")).isDisplayed()) {
					Thread.sleep(2000);
				} else {
					break;
				}
			}
		} catch (Exception e) {

		}
	}

	public void clickOnNonHiddenElement(String propName) throws Throwable {
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {
				List<WebElement> link = findElements(propName);
				for (int i = 0; i < link.size(); i++) {
					if (link.get(i).isDisplayed()) {
						link.get(i).click();
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
	}

	public void click(By locator) throws IOException {
		FluentWait<WebDriver> wait = getFluentWait();
		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
		} catch (WebDriverException webDriverException) {
			if (webDriverException.getMessage().contains("Element is not clickable at point")) {
			//	clickUsingJSExecutor(locator);
			} else {
				throw webDriverException;
			}
		}
	}

	public void maximize() throws IOException {
		getCurrentDriver().manage().window().maximize();
	}

//	public void clickUsingJSExecutor(String propName) throws IOException {
//		By by = ByOperations.getByargument(propName);
//		clickUsingJSExecutor(by);
//	}

	public void clickUsingJSExecutor(WebElement webElement) throws IOException {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) getCurrentDriver();
		jsExecutor.executeScript("arguments[0].click();", webElement);
		waitForPageLoad();
	}

	public void clickUsingJSExecutor(String locator) throws IOException {
//		FluentWait<WebDriver> wait = getFluentWait();
//		WebElement webElement = wait.until(ExpectedConditions.elementToBeClickable(locator));
		clickUsingJSExecutor(findElement(locator));
	}

	public void check(String propName) throws IOException {
		if (!findElement(propName).isSelected())
			click(propName);
	}

	public void uncheck(String propName) throws IOException {
		if (findElement(propName).isSelected())
			click(propName);
	}

	public String capturePageTitle() throws IOException {
		return getCurrentDriver().getTitle();
	}

	public void closeCurrentActiveBrowser() throws IOException {
		windowHandlesList.get(getCurrentThreadName()).remove(getCurrentDriver().getWindowHandle());
		try {
			getCurrentDriver().close();
		} catch (Exception e) {

		}
	}

	public String acceptAlert() throws IOException {
		String alertText = "";
		FluentWait<WebDriver> fluentWait = getFluentWait();
		fluentWait.until(ExpectedConditions.alertIsPresent());
		alertText = getCurrentDriver().switchTo().alert().getText();
		getCurrentDriver().switchTo().alert().accept();
		return alertText;
	}

	public String dismissAlert() throws IOException {
		String alertText = "";
		FluentWait<WebDriver> fluentWait = getFluentWait();
		fluentWait.until(ExpectedConditions.alertIsPresent());
		alertText = getCurrentDriver().switchTo().alert().getText();
		getCurrentDriver().switchTo().alert().dismiss();
		return alertText;
	}

	public boolean isAlertPresent() {
		try {
			getCurrentDriver().switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public String handleproxydialog(String username, String password) throws IOException {
		String alertText = "";
		FluentWait<WebDriver> fluentWait = getFluentWait();
		fluentWait.until(ExpectedConditions.alertIsPresent());
		alertText = getCurrentDriver().switchTo().alert().getText();
		Credentials user = new UserAndPassword(username, password);
		getCurrentDriver().switchTo().alert().authenticateUsing(user);
		return alertText;
	}

	public void get(String strURL) throws IOException {
		getCurrentDriver().get(strURL);
	}

	public boolean isDisplayed(String propName) throws IOException {
		if (findElements(ByOperations.getByargument(propName)).size() > 0) {
			return true;
		}
		return false;
	}

	public boolean isEnabled(String propName) throws IOException {
		if (findElement(propName).isEnabled())
			return true;
		return false;
	}

	public boolean isSelected(String propName) throws IOException {
		if (findElement(propName).isSelected())
			return true;
		return false;
	}

	public void pressKeyEvent(String Key) throws Exception {
		// Thread.sleep(3000);
		Robot rb = new Robot();
		if (Key.equals("ESCAPE")) {
			rb.keyPress(KeyEvent.VK_ESCAPE);
			rb.keyRelease(KeyEvent.VK_ESCAPE);
		} else if (Key.equals("TAB")) {
			rb.keyPress(KeyEvent.VK_TAB);
			rb.keyRelease(KeyEvent.VK_TAB);
		}
	}

	public String captureToolTipText(String propName) throws IOException {
		Actions seriesofAction = new Actions(getCurrentDriver());
		WebElement NewButton = findElement(propName);
		seriesofAction.moveToElement(NewButton).build().perform();
		String Tooltip = NewButton.getAttribute("title");
		seriesofAction.release();
		return Tooltip;
	}

	public void mouseHover(String propName) throws IOException {
		Actions seriesofAction = new Actions(getCurrentDriver());
		WebElement NewButton = findElement(propName);
		seriesofAction.moveToElement(NewButton).perform();
	}
	
	public void mouseHoverRelease(String propName) throws IOException {
		Actions seriesofAction = new Actions(getCurrentDriver());
		WebElement NewButton = findElement(propName);
		seriesofAction.release(NewButton).release().perform();	
		
	}

	public void dblclick(String propName) throws IOException {
		Actions seriesofAction = new Actions(getCurrentDriver());
		WebElement NewButton = findElement(propName);
		seriesofAction.doubleClick(NewButton).perform();
	}
	private void addWindowHandleToArrayList() {
		for (String winHandle : driverList.get(getCurrentThreadName()).getWindowHandles()) {
			if (!windowHandlesList.get(getCurrentThreadName()).contains(winHandle)) {
				windowHandlesList.get(getCurrentThreadName()).add(winHandle);
			}
		}

	}

	public void switchtonewwindow() throws Exception {
		addWindowHandleToArrayList();
		try {
			getCurrentDriver().switchTo().window(windowHandlesList.get(getCurrentThreadName())
					.get(windowHandlesList.get(getCurrentThreadName()).size() - 1));
		} catch (Exception e) {

		}
	}

	public void uncheckAllCheckboxes() throws Exception {
		List<WebElement> checkboxs = findElements(By.xpath("//input[@type='checkbox']"));

		for (int i = 0; i < checkboxs.size(); i++)
			if (checkboxs.get(i).isDisplayed()) {
				if (checkboxs.get(i).isSelected()) {
					click(checkboxs.get(i));
				}
			}
	}

	public void click(WebElement webElement) throws IOException {
		try {
			webElement.click();
		} catch (WebDriverException webDriverException) {
			if (webDriverException.getMessage().contains("Element is not clickable at point")) {
				JavascriptExecutor jsExecutor = (JavascriptExecutor) getCurrentDriver();
				jsExecutor.executeScript("arguments[0].click();", webElement);
			} else {
				throw webDriverException;
			}
		}
	}

	public void checkAllCheckboxes() throws Exception {
		List<WebElement> checkboxs = findElements(By.xpath("//input[@type='checkbox']"));
		for (int i = 0; i < checkboxs.size(); i++)
			if (checkboxs.get(i).isDisplayed()) {
				if (!checkboxs.get(i).isSelected()) {
					click(checkboxs.get(i));
				}
			}
	}

	public void back() throws IOException {
		getCurrentDriver().navigate().back();
	}

	public void refresh() throws IOException {
		getCurrentDriver().navigate().refresh();
	}

	public String getCurrentUrl() throws IOException {
		return this.getCurrentDriver().getCurrentUrl();
	}

	public String getAttributeValue(String propName, String AttributeName) throws IOException {
		return findElement(propName).getAttribute(AttributeName);
	}

	public String getSelectedItemValueInList(String propName) throws Exception {
		Select select = new Select(findElement(propName));
		//return select.getFirstSelectedOption().getAttribute("value");
		return select.getFirstSelectedOption().getText();
	}

	public void switchControlToHTML(String frameName) throws IOException {
		getCurrentDriver().switchTo().defaultContent();
		getCurrentDriver().switchTo().frame(findElement(frameName));
	}

	public void switchtodefaultContent() throws IOException {
		getCurrentDriver().switchTo().defaultContent();
	}

	public List<WebElement> getAllDropdownListOptions(String propName) throws Exception {
		WebElement elem = findElement(propName);
		Select select = new Select(elem);
		List<WebElement> options = select.getOptions();
		return options;
	}

	public void selectDropdownListOptionWithPartialText(String propName, String text) throws Exception {

		List<WebElement> optionsList = getAllDropdownListOptions(propName);
		for (WebElement option : optionsList) {
			if (option.getText().contains(text)) {
				option.click();
				break;
			}
		}
	}

	public boolean isOptionPresentInDropDownListOptions(String propName, String optionValue) throws Exception {
		boolean returnValue = false;
		List<WebElement> optionsList = getAllDropdownListOptions(propName);
		for (WebElement option : optionsList) {
			if (option.getText().equals(optionValue)) {
				returnValue = true;
				break;
			}
		}
		return returnValue;
	}

	public int getSizeofListbox(String propName) throws Exception {
		
		WebElement list = findElement(propName);
		List<WebElement> lstOptions = list.findElements(By.tagName("option"));
					
		int returnValue=lstOptions.size();			
		
		return returnValue;
	}
	
	public void selectAllItemsFromListbox(String propName) throws IOException {

		WebElement list = findElement(propName);
		List<WebElement> lstOptions = list.findElements(By.tagName("option"));
		list.sendKeys(Keys.CONTROL);
		for (int i = 0; i < lstOptions.size(); i++) {
			if (!lstOptions.get(i).isSelected()) {
				lstOptions.get(i).click();
			
			}
		}

	}

	public void deSelectAllItemsFromListbox(String propName) throws IOException {

		WebElement list = findElement(propName);
		List<WebElement> lstOptions = list.findElements(By.tagName("option"));
		list.sendKeys(Keys.CONTROL);
		for (int i = 0; i < lstOptions.size(); i++) {
			if (lstOptions.get(i).isSelected()) {
				lstOptions.get(i).click();
			}
		}

	}

	@SuppressWarnings("unused")
	public List<WebElement> getAllSelectedItemsFromListbox(String propName) throws IOException {
		List<WebElement> allselectedItems = new ArrayList<WebElement>();
		WebElement list = findElement(propName);
		Select sel = new Select(list);
		return allselectedItems = sel.getAllSelectedOptions();
	}

	public String getNonHiddenElementText(String propName) throws Throwable {
		String element = null;
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {
				List<WebElement> link = findElements(propName);
				for (int i = 0; i < link.size(); i++) {
					if (link.get(i).isDisplayed()) {
						element = link.get(i).getAttribute("value");
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
		return element;
	}

	public boolean getNonHiddenElementEnable(String propName) throws Throwable {
		boolean flag = false;
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {
				List<WebElement> link = findElements(propName);
				for (int i = 0; i < link.size(); i++) {
					if (link.get(i).isDisplayed()) {
						flag = link.get(i).isEnabled();
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
		return flag;
	}

	public void clickNonHiddenElement(String propName) throws Throwable {
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {
				List<WebElement> link = findElements(propName);
				for (int i = 0; i < link.size(); i++) {
					if (link.get(i).isDisplayed()) {
						link.get(i).click();
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
	}

	public void clickNonHiddenWebElement(List<WebElement> wb) throws Throwable {
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {

				for (int i = 0; i < wb.size(); i++) {
					if (wb.get(i).isDisplayed()) {
						wb.get(i).click();
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
	}

	public void selectonHiddenElement(String propName, String value) throws Throwable {
		boolean blnContinueWhile = true;
		while (blnContinueWhile) {
			blnContinueWhile = false;
			try {
				List<WebElement> link = findElements(propName);
				for (int i = 0; i < link.size(); i++) {
					if (link.get(i).isDisplayed()) {
						Select sel = new Select(link.get(i));
						sel.selectByVisibleText(value);
						break;
					}
				}
			} catch (StaleElementReferenceException staleElementReferenceException) {
				blnContinueWhile = true;
			}
		}
	}

	public static int getrandomnumber(int high, int low) throws IOException {
		Random rnum = new Random();
		return rnum.nextInt(high - low) + low;

	}

	public void explicitwait(String property) throws IOException {
		WebDriverWait wait = new WebDriverWait(getCurrentDriver(), 60);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(ByOperations.getByargument(property)));
	}

	public void explicitWaitWithStaleElement(String property) throws IOException {
		WebDriverWait wait = new WebDriverWait(getCurrentDriver(), 500);
		wait.until(ExpectedConditions.visibilityOf(findElement(ByOperations.getByargument(property))));
	}

	public void sendvalue(String propName, String strValue) throws IOException {
		WebElement webElement = getCurrentDriver().findElement(ByOperations.getByargument(propName));
		Actions act = new Actions(getCurrentDriver());
		act.sendKeys(webElement, strValue).build().perform();

	}

	public void clearvalue(String propName) throws IOException, InterruptedException {
		WebElement webElement = getCurrentDriver().findElement(ByOperations.getByargument(propName));
		Actions act = new Actions(getCurrentDriver());
		act.sendKeys(webElement, Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys("\u0008").build().perform();

	}

	public String getCurrentWindowHandle() throws IOException {
		return getCurrentDriver().getWindowHandle();

	}

	public void switchToWindow(String parentWindow) throws IOException {
		getCurrentDriver().switchTo().window(parentWindow);
	}

	public void pressCONTROLKeyEvent() throws AWTException {
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_CONTROL);
	}

	public void rleaseCONTROLKeyEvent() throws AWTException {
		Robot rb = new Robot();
		rb.keyRelease(KeyEvent.VK_CONTROL);
	}
	
	public void Robot() throws AWTException {
		@SuppressWarnings("unused")
		Robot rb = new Robot();
	}
	
	public void Capturescreenshot (String config)throws AWTException {
	try {
    	Robot robot = new Robot();
    	String format = "bmp";
        String fileName = System.getProperty("user.dir")+"/"+config+"."+format; 
        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
		ImageIO.write(screenFullImage, "png", new File(fileName));
	} catch (IOException e) { 
		e.printStackTrace();
	}
	}
	
	public void Getcolumnvalue(String propName,String matchVal ) throws Exception {		
		//WebElement Webtable = getCurrentDriver().findElement(ByOperations.getByargument(propName));
		
		//WebElement Webtable=findElement(By.xpath("//table[@class='dataGrid'][@id='ctl00_SummaryPlaceHolder_moDealerController_moDataGrid']")); // Replace TableID with Actual Table ID or Xpath

		//List<WebElement> TotalRowCount=Webtable.findElements(By.xpath("//*[@id='ctl00_SummaryPlaceHolder_moDealerController_moDataGrid']/tbody/tr"));		
		List<WebElement> TotalRowCount=findElements(ByOperations.getByargument(propName));
	
		System.out.println("No. of Rows in the WebTable: "+TotalRowCount.size());
		// Now we will Iterate the Table and print the Values   
		int RowIndex=1;

		for(WebElement rowElement:TotalRowCount)
		{
		      List<WebElement> TotalColumnCount=rowElement.findElements(By.tagName("td"));
		      int ColumnIndex=1;
		      for(WebElement colElement:TotalColumnCount)
		      {	    	  		    	  
		    	  
		           System.out.println("Row "+RowIndex+" Column "+ColumnIndex+" Data "+colElement.getText());
		           System.out.println("Row "+RowIndex+" Column "+ColumnIndex+" Data "+colElement.getAttribute("input"));
		           ColumnIndex=ColumnIndex+1;
		            String tableval=colElement.getText();
		           if (tableval.trim().equalsIgnoreCase(matchVal)) {		        	   
		        	   colElement.click();
		        	   break;
		   			
		   		} else {
		   					
		   			
		   		}	           
		                   
		           
		           
		       }
		      RowIndex=RowIndex+1;
		     
		 }  
	
	}
	
	
	
	

	public void scrollwindow() {
		try {
			((JavascriptExecutor) getCurrentDriver()).executeScript("window.scrollBy(0,250)", "");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public Boolean checkImageValidity(String propName) throws MalformedURLException, IOException{
		WebElement Im =  getCurrentDriver().findElement(ByOperations.getByargument(propName));
	    String Source = Im.getAttribute("src");
	    try{
	    BufferedImage img=ImageIO.read(new URL(Source));
	    img.getHeight();
	    return true;
	    }
	    catch(IllegalArgumentException e){
	        return false;
	    }

	}
	

    public void CaptureScreenshotBilling (String config)throws AWTException {
    try {
    Robot robot = new Robot();
    String format = "bmp";
    String fileName = System.getProperty("user.dir")+"/BillingPaymentsReports/"+config+"."+format; 
    Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
    BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
                    ImageIO.write(screenFullImage, "png", new File(fileName));
    } catch (IOException e) {
                    e.printStackTrace();
    }
    }
    
    public void ScreenShotBilling(String args) throws AWTException, InterruptedException{
        String coun=args;
        
        for(int i=0; i<2; i++){   
              findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, Keys.SUBTRACT));
        }

        CaptureScreenshotBilling(coun);
        
        
        findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
        
        Thread.sleep(1000);

    }
    
    
    public void CaptureScreenshotClaim (String config)throws AWTException {
    try {
    Robot robot = new Robot();
    String format = "bmp";
    String fileName = System.getProperty("user.dir")+"/ClaimsReports/"+config+"."+format; 
    Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
    BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
                    ImageIO.write(screenFullImage, "png", new File(fileName));
    } catch (IOException e) {                    
                    e.printStackTrace();
    }
    }
    
    public void ScreenShotClaim(String args) throws AWTException, InterruptedException{
        String coun=args;
        
        for(int i=0; i<2; i++){   
              findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, Keys.SUBTRACT));
        }

        CaptureScreenshotClaim(coun);
        
        
        findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL, "0"));
        
        Thread.sleep(1000);

    }
    
    public void JSAcceptAlert() {
    	try{
    	((JavascriptExecutor)getCurrentDriver()).executeAsyncScript("window.confirm =function(msg) {return true;};");
    	}catch(Exception e){
    		try{
    			((JavascriptExecutor)getCurrentDriver()).executeAsyncScript("window.alert =function(msg) {};");
    			}catch(Exception a){
    				a.printStackTrace();
    		}
    	}
//    	Alert alert=getCurrentDriver().switchTo().alert();
//    	alert.accept();
	}
    
    public void JSDismissAlert() throws IOException {
    	((JavascriptExecutor)getCurrentDriver()).executeAsyncScript("window.confirm =function(msg) {return false;};");
    	Alert alert=getCurrentDriver().switchTo().alert();
    	alert.dismiss();
	}
    
    
    public void sendKeysHideenElement(String propName, String InputValue){
    	try {
    	JavascriptExecutor jsExecutor = (JavascriptExecutor) getCurrentDriver();
    	jsExecutor.executeScript("document.getElementById('"+FileOperations.DerivergetProperty(propName)+"').setAttribute('value','"+InputValue+"')");
    	}catch(Exception e){
    		
    	}
    }
    
    
    public void JSClickDisabledElement(String propName){
    	try {
    	JavascriptExecutor js = (JavascriptExecutor) getCurrentDriver();
    	js.executeScript("document.querySelector("+FileOperations.DerivergetProperty(propName)+").click()");
    	}catch(Exception e){
    		
    	}
    }
    
    
  //end of class
}
