
package com.deloitte.mobileapplication.webdriverinteraction;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.deloitte.mobileapplication.appconstants.AppConstants;
import com.deloitte.mobileapplication.fileOperations.FileOperations;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class BrowserFactory {
	public static WebDriver driver;
	public static RemoteWebDriver _driver;
	public static AppiumDriver<WebElement> ndriver;
	/**
	 * This method will open browser according to user argument passed
	 * 
	 * @param browser
	 * @return it will return the driver
	 * @throws IOException 
	 */
	public static WebDriver getBrowser() throws IOException {
		String browser = FileOperations.DerivergetProperty(AppConstants.BROWSER);
		switch (browser.toUpperCase()) {
		
		case "CHROME":
			driver = chromebrowser();
			break;
		case "SAFARI":
			driver = chromebrowser();
			break;

		}
		return driver;

	}
	
	public static WebDriver chromebrowser() throws IOException {
	     DesiredCapabilities capabilities = DesiredCapabilities.android();
	     capabilities.setCapability("deviceName", "emulator-5554");
	     capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
         capabilities.setCapability("platformName", "Android");         
         capabilities.setCapability("platformVersion","11");
         capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome");     //       
         driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);             

        return driver;
	}

	public static WebDriver App() throws IOException {
	     DesiredCapabilities capabilities = DesiredCapabilities.android();
	     capabilities.setCapability("deviceName", "emulator-5554");
	     capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
        capabilities.setCapability("platformName", "Android");         
        //capabilities.setCapability("platformVersion","11");      
        capabilities.setCapability("appPackage", "com.android.contacts");
        capabilities.setCapability("appActivity", "com.android.contacts.activities.PeopleActivity");           
        ndriver = new AndroidDriver<WebElement> (new URL("http://127.0.0.1:4723/wd/hub"),capabilities);      
        ndriver.findElement(By.id("com.android.contacts:id/floating_action_button")).click();
        ndriver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        ndriver.findElement(By.id("com.android.contacts:id/left_button")).click();
        ndriver.findElement(By.xpath("//*[contains(@text,'Last name')]")).sendKeys("Hello");
        ndriver.findElement(By.xpath("//*[contains(@text,'Phone')]")).sendKeys("9742110936");        
        ndriver.findElement(By.id("com.android.contacts:id/editor_menu_save_button")).click();            
        return  ndriver;
	}

		


// end of class
}