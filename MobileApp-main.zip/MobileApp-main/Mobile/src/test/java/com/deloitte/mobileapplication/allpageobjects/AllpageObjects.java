
package com.deloitte.mobileapplication.allpageobjects;
import com.deloitte.mobileapplication.reusable.LoginToApplication;
import com.deloitte.mobileapplication.webdriverinteraction.WebDriverInteractions;
import com.deloitte.mobileapplication.webdriverinteraction.BrowserFactory;
import com.deloitte.mobileapplication.webdriverinteraction.AppFactory;

public class AllpageObjects {
	public WebDriverInteractions webdriverintractions;
	public LoginToApplication logintoapplication;	
	
	public BrowserFactory BrowserFactory;
	public AppFactory AppFactory;
	
	
	
	
	public AllpageObjects() {
		
		webdriverintractions=new WebDriverInteractions();
		BrowserFactory =new BrowserFactory();
		AppFactory =new AppFactory();		
		logintoapplication=new LoginToApplication(webdriverintractions);		
		
		
	}
	
//end of class
}
