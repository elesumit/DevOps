
package com.deloitte.mobileapplication.reusable;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.deloitte.mobileapplication.appconstants.AppConstants;
import com.deloitte.mobileapplication.fileOperations.FileOperations;
import com.deloitte.mobileapplication.webdriverinteraction.AppFactory;
import com.deloitte.mobileapplication.webdriverinteraction.BrowserFactory;
import com.deloitte.mobileapplication.webdriverinteraction.WebDriverInteractions;

import io.appium.java_client.AppiumDriver;

public class LoginToApplication {
	protected WebDriverInteractions webDriverInteractions;
	public LoginToApplication( WebDriverInteractions webdriverintractions){
		this.webDriverInteractions=webdriverintractions;
	}
	public void logintoapplication(String emailid,String password,String message) throws IOException{
		Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
			webDriverInteractions.sendKeys("Loginpage.txtUserName", emailid);			
			webDriverInteractions.waitForPageLoad();
			webDriverInteractions.sendKeys("Loginpage.txtPassword", password);
			webDriverInteractions.waitForPageLoad();
			webDriverInteractions.click("Loginpage.Submit");
			if(webDriverInteractions.captureText("").contains(message)){
				Assert.assertTrue(webDriverInteractions.captureText("").contains(message));
				webDriverInteractions.waitForPageLoad();
			}else{
				Assert.assertTrue(webDriverInteractions.captureText("").contains(message));
				webDriverInteractions.waitForPageLoad();
			}


	}
	
	public void login(String url) throws IOException, NoSuchFieldException, SecurityException, ClassNotFoundException{
	
	String browser=	FileOperations.DerivergetProperty(AppConstants.BROWSER);
	switch (browser.toUpperCase()) {
	case "SAFARI":
		Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
		break;
	case "CHROME":
		Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
		break;
	}
	

	switch(url.toUpperCase()){
	case "MODELA1":			
		webDriverInteractions.get(FileOperations.DerivergetProperty(AppConstants.MODLA1));
		webDriverInteractions.sendKeys("Loginpage.txtUserName", "sunilyb");			
		webDriverInteractions.sendKeys("Loginpage.txtPassword", "password");
		webDriverInteractions.click("Loginpage.Submit");
		webDriverInteractions.waitForPageLoad();
	
	break;

    	
    
	}

	
	
		
}
	
	//end of class
}

