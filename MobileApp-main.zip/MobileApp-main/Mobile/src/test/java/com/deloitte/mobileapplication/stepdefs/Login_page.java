package com.deloitte.mobileapplication.stepdefs;

import java.awt.Robot;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.deloitte.mobileapplication.allpageobjects.AllpageObjects;
import com.deloitte.mobileapplication.reusable.LoginToApplication;
import com.deloitte.mobileapplication.webdriverinteraction.BrowserFactory;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Login_page {

	public AllpageObjects allpageobjects;
	protected Scenario scenario;
	public static String NewDealerName, NewCloneDealerName, NewCertificateProdCode, NewCertificateClonedProdCode;

	public Login_page(AllpageObjects allpageobjects) {
		this.allpageobjects = allpageobjects;
	}

	@Before
	public void setUp(Scenario scenario) {
		this.scenario = scenario;
	}

	@Given("^I want to write a step with precondition$")
	public void i_want_to_write_a_step_with_precondition() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		allpageobjects.logintoapplication.login("MODELA1");	
		
		
	}

	

	//end of class
}
	

