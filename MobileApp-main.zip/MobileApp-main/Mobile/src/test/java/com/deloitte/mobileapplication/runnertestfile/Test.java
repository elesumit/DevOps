package com.deloitte.mobileapplication.runnertestfile;

import org.junit.runner.RunWith;

import com.deloitte.mobileapplication.cucumberReport.ExtendedCucumber;
import com.deloitte.mobileapplication.cucumberReport.ExtendedCucumberOptions;

import cucumber.api.CucumberOptions;

@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(jsonReport = "target/cucumber.json",
        //retryCount = 1,
        detailedReport = true,
        overviewReport = true,
        excludeCoverageTags = {"@flaky"},
        includeCoverageTags = {"@passed"},
        screenShotLocation = "Reports/Screens/",
        screenShotSize = "100px",
        outputFolder = "Reports")
@CucumberOptions(plugin = {"html:target/cucumber-html-report",
        "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
        "usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml"},       
       features = { "classpath:scenarios" },
        glue = {"com.deloitte.mobileapplication.stepdefs",},
        tags = {"@tag"})




public class Test {

}
