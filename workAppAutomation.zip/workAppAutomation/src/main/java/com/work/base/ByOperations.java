package com.work.base;
import org.openqa.selenium.By;

import io.appium.java_client.AppiumBy;

public class ByOperations {
	
	public static By getByargument(String property){
		By by=null;
		String byValue=FileOperations.DerivergetProperty(property).split(";")[1];
		String byType=FileOperations.DerivergetProperty(property).split(";")[0];
		switch(byType.toUpperCase()){
		case "ID":
			by=	By.id(byValue);
			break;
		case "XPATH":
			by=By.xpath(byValue);
			break;
		case "accessibilityId":
			by=AppiumBy.accessibilityId(byValue);
			break;

		}
		
		return by;
		
	}
	
	//end of class
}