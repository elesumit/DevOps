package com.work.base;
public class AppConstants {
	public static String platform = System.getProperty("platform", "android");
    public static String isCloud = System.getProperty("isCloud", "true");
    public static String UserName = System.getProperty("UserName", "Sumit");
    public static String Password = System.getProperty("Password", "Sumit");
    public static String BrowserstackUserName = System.getProperty("BrowserstackUserName", "sunnyvivek_9z4dZi");
    public static String BrowserstackKey = System.getProperty("BrowserstackKey", "fqP9bWM1o4ByTzhquHzz");

	
	//end of class
}
