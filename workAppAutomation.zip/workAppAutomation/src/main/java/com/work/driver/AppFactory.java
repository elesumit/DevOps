package com.work.driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.testng.SkipException;

import com.work.base.AppConstants;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class AppFactory {
    static AppiumDriver driver;
    static HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();

    private static void android_launchApp() throws MalformedURLException, InterruptedException {

         UiAutomator2Options options = new UiAutomator2Options();

        if(AppConstants.isCloud.contains("false")){
            options.setDeviceName("emulator-5554")
                    .setPlatformVersion("13.0")
                    .setAppPackage("com.saucelabs.mydemoapp.rn")
                    .setAppActivity(".MainActivity");
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);

        }else 
        {       
        	browserstackOptions.put("userName",AppConstants.BrowserstackUserName);
            browserstackOptions.put("accessKey",AppConstants.BrowserstackKey);
            browserstackOptions.put("appiumVersion", "2.4.1");
    		options.setDeviceName("Google Pixel 3")
            .setPlatformVersion("9.0")
            .setAppPackage("com.sightplan.sightplanmobile.beta")
    		.setAppWaitActivity("com.sightplan.sightplanmobile.authentication.AuthenticationActivity")	
           .setApp("bs://4dcf2285303e1b029e12032f1ce277a0ab74de4e")        
            .setCapability("bstack:options", browserstackOptions);
    		driver = new AndroidDriver(new URL("http://hub-cloud.browserstack.com/wd/hub"), options);
    		 Thread.sleep(10000);

        }

        AppDriver.setDriver(driver);
        System.out.println("AndroidDriver is set");
    }

    private static void ios_launchApp() throws MalformedURLException, MalformedURLException {
        XCUITestOptions options = new XCUITestOptions();
        //browserstackOptions = getBrowserstackOptions();

        if(AppConstants.isCloud.contains("false")){
            options.setDeviceName("iPhone 15")
                    .setPlatformVersion("17.2")
                    .setBundleId("com.saucelabs.mydemoapp.rn");
            driver = new IOSDriver(new URL("http://127.0.0.1:4723/"), options);
        }else { //browserstack
            options.setDeviceName("iPhone 15")
                    .setPlatformVersion("17")
                    .setBundleId("com.saucelabs.mydemoapp.rn")
                    .setApp("bs://22aa9fadc1e95af6304472c4e1bdf437e0bd10f3")
                    .setCapability("bstack:options", browserstackOptions);
            driver = new IOSDriver(new URL("http://hub-cloud.browserstack.com/wd/hub"), options);
        }

        AppDriver.setDriver(driver);
        System.out.println("IOSDriver is set");
    }

    public static void launchApp() throws MalformedURLException, InterruptedException {
        System.out.println("entering into launchapp");
        if(AppConstants.platform.contains("ios")){
            ios_launchApp();
            System.out.println("iOS launched...");
        }else
            if(AppConstants.platform.contains("android")){
                android_launchApp();
                System.out.println("Android launched...");
            }else
                throw new SkipException("Enter valid platform value, android/ios");
    }



}
