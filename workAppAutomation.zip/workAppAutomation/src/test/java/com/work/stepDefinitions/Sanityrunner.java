package com.work.stepDefinitions;

import io.cucumber.testng.AbstractTestNGCucumberTests;

@io.cucumber.testng.CucumberOptions(features = "src/test/java", strict = true, plugin = {"json:target/cucumber.json","html:target/site/cucumber-pretty"},glue = "com.work.stepDefinitions")
public class Sanityrunner extends AbstractTestNGCucumberTests {
 
}
