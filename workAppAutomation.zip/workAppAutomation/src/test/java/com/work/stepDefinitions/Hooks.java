package com.work.stepDefinitions;
import java.io.IOException;
import com.work.driver.AppFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	
	
	@Before
    public void beforeScenario() throws IOException, InterruptedException{
		
		
        System.out.println("before method");
        AppFactory.launchApp();
        
    } 
	
	@After
    public void afterScenario(io.cucumber.java.Scenario sc)
    {   
		
}}
