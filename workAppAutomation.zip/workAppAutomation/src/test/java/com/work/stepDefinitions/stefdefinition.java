package com.work.stepDefinitions;
import com.work.base.AppConstants;
import com.work.base.AppDriverInteractions;

import io.cucumber.java.en.Given;


public class stefdefinition  extends AppDriverInteractions {


	@Given("I want to login to the work app")
	public void i_want_to_login_to_the_work_app() {		
		
//    	AppDriverInteractions.waitNtype("UserName",AppConstants.UserName);
//    	AppDriverInteractions.type("PassWord", AppConstants.Password);
//    	AppDriverInteractions.click("");
	}
}
